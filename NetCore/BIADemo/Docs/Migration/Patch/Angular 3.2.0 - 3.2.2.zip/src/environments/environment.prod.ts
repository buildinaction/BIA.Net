import {NgxLoggerLevel} from 'ngx-logger';

export const environment = {
  apiUrl: '../WebApi/api',
  urlAuth: '/api/Auth',
  urlLog: '/api/logs',
  urlEnv: '/api/Environment',
  urlErrorPage: '/static/error.htm',
  urlDMIndex: '/DMIndex',
  urlAppIcon: 'assets/bia/AppIcon.svg',
  useXhrWithCred: false,
  production: true,
  appTitle: 'BIATemplate',
  companyName: 'Safran',
  version: '1.2.2',
  logging: {
    conf: {
      serverLoggingUrl: '../WebApi/api/logs',
      level: NgxLoggerLevel.DEBUG,
      serverLogLevel: NgxLoggerLevel.ERROR
    }
  }
};
