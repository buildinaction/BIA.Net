import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { GenericDas } from './generic-das.service';
import { EnvironmentType } from 'src/app/shared/constants';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class BiaEnvironmentService {
  private route: string;
  constructor(private http: HttpClient) {
    this.route = GenericDas.buildRoute('environment');
  }

  getType(): Observable<EnvironmentType> {
    return this.http.get<EnvironmentType>(`${this.route}type`);
  }
}
