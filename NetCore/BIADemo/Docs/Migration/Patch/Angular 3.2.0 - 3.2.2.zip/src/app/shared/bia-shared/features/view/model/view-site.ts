export interface ViewSite {
    siteId: number;
    siteTitle: string;
    isDefault: boolean;
}
