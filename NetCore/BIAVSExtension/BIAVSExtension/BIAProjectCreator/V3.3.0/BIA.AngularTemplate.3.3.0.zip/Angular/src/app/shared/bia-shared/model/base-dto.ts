import { DtoState } from './dto-state.enum';

export class BaseDto {
  id: number;
  dtoState: DtoState;
}
