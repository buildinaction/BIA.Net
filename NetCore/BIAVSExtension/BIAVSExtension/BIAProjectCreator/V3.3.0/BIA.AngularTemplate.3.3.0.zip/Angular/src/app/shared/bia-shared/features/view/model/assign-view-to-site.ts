export interface AssignViewToSite {
  viewId: number;
  siteId: number;
  isAssign: boolean;
}
