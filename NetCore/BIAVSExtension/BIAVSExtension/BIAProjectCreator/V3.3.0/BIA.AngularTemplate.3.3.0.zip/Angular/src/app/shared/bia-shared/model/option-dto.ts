import { BaseDto } from 'src/app/shared/bia-shared/model/base-dto';

export interface OptionDto extends BaseDto {
  display: string;
}
