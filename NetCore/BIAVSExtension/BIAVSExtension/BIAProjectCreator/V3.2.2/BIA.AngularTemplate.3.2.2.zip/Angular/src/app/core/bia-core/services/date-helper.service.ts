import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DateHelperService {

constructor() { }

public static isDate(value: any): boolean {
  const regex = /(\d{4})-(\d{2})-(\d{2})T/;
  if (typeof value === 'string' && value.match(regex)) {
    const date = Date.parse(value);
    return !isNaN(date);
  }
  return false;
}

public static fillDate<TOut>(data: TOut) {
  Object.keys(data).forEach((key: string) => {
    if (DateHelperService.isDate((data as any)[key])) {
      (data as any)[key] = new Date((data as any)[key]);
    }
  });
}

}
