export interface SiteMember {
  userFirstName: string;
  userLastName: string;
  userLogin: string;
}
