export interface SiteAdvancedFilter {
  userId: number;
}
