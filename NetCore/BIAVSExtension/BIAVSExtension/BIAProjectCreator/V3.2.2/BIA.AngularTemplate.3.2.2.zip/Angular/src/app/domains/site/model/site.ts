export interface Site {
  id: number;
  title: string;
  isDefault: boolean;
}
