import { Component, Input, Output, EventEmitter } from '@angular/core';
import { View } from '../../model/view';
import { AssignViewToSite } from '../../model/assign-view-to-site';
import { ViewSite } from '../../model/view-site';
import { Site } from 'src/app/domains/site/model/site';

@Component({
  selector: 'app-view-site-table',
  templateUrl: './view-site-table.component.html',
  styleUrls: ['./view-site-table.component.scss']
})
export class ViewSiteTableComponent {
  @Input() views: View[];
  @Input() siteSelected: Site;
  @Input() canDelete = false;
  @Input() canSetDefault = false;
  @Input() canUpdate = false;
  @Input() canAssign = false;

  viewSelected: View;

  @Output() assignViewToSite = new EventEmitter<AssignViewToSite>();
  @Output() delete = new EventEmitter<number>();
  @Output() setDefault = new EventEmitter<{ viewId: number; isDefault: boolean }>();
  @Output() viewSelect = new EventEmitter<View>();

  constructor() {}

  onDeleteView(viewId: number) {
    this.delete.emit(viewId);
  }

  onAssignViewToSite(viewId: number, isAssign: boolean) {
    this.assignViewToSite.emit(<AssignViewToSite>{ viewId: viewId, siteId: this.siteSelected.id, isAssign: isAssign });
  }

  onSetDefaultView(viewId: number, isDefault: boolean) {
    this.setDefault.emit({ viewId, isDefault });
  }

  onRowSelected(view: View) {
    this.viewSelected = view;
    this.viewSelect.emit(this.viewSelected);
  }

  onRowUnselected() {
    this.viewSelected = <View>{};
    this.viewSelect.emit(this.viewSelected);
  }

  formatSites(viewSites: ViewSite[]) {
    if (viewSites) {
      return viewSites.map((x) => x.siteTitle).join(', ');
    } else {
      return '';
    }
  }

  containsCurrentSite(view: View) {
    if (view && view.viewSites && this.siteSelected) {
      return view.viewSites.some((x: ViewSite) => x.siteId === this.siteSelected.id);
    }
    return false;
  }

  isSiteDefault(view: View): boolean {
    if (view && view.viewSites && this.siteSelected) {
      return view.viewSites.some((x: ViewSite) => x.siteId === this.siteSelected.id && x.isDefault === true);
    }
    return false;
  }

  showActionCol() {
    return this.canDelete === true || this.canSetDefault === true || this.canAssign === true;
  }
}
