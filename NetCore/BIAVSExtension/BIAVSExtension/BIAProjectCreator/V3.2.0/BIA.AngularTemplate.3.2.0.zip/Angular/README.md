# Safran Framework

Safran Framework is a development platform for building mobile and desktop web applications using Angular.

## New Project

[Get started a new project][newproject].

## Changelog

[Learn about the latest improvements][changelog].

[newproject]: ./docs/NEW_PROJECT.md
[changelog]: ./CHANGELOG.md