export const FRAMEWORK_VERSION = '3.2.0';
