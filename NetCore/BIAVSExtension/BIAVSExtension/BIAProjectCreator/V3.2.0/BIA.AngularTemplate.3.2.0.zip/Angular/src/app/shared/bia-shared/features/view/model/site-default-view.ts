import { DefaultView } from './default-view';

export interface SiteDefaultView extends DefaultView {
  siteId: number;
}
