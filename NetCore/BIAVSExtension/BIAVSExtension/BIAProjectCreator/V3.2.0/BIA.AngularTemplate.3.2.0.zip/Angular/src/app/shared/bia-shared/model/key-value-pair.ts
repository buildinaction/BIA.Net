export interface KeyValuePair {
  key: any;
  value: any;
}
