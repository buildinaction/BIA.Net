import { Component, Input, Output, EventEmitter } from '@angular/core';
import { View } from '../../model/view';

@Component({
  selector: 'app-view-user-table',
  templateUrl: './view-user-table.component.html',
  styleUrls: ['./view-user-table.component.scss']
})
export class ViewUserTableComponent {
  @Input() views: View[];
  @Input() canDelete = false;
  @Input() canSetDefault = false;
  @Input() canUpdate = false;

  viewSelected: View;

  @Output() delete = new EventEmitter<number>();
  @Output() setDefault = new EventEmitter<{ viewId: number; isDefault: boolean }>();
  @Output() viewSelect = new EventEmitter<View>();

  constructor() {}

  onDeleteView(viewId: number) {
    this.delete.emit(viewId);
  }

  onSetDefaultView(viewId: number, isDefault: boolean) {
    this.setDefault.emit({ viewId, isDefault });
  }

  onRowSelected(view: View) {
    this.viewSelected = view;
    this.viewSelect.emit(this.viewSelected);
  }

  onRowUnselected() {
    this.viewSelected = <View>{};
    this.viewSelect.emit(this.viewSelected);
  }

  showActionCol() {
    return this.canDelete === true || this.canSetDefault === true;
  }
}
