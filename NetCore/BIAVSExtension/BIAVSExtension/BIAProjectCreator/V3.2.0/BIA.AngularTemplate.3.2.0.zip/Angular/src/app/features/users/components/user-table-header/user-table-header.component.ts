import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Location } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'user-table-header',
  templateUrl: './user-table-header.component.html',
  styleUrls: ['./user-table-header.component.scss']
})
export class UserTableHeaderComponent implements OnInit {
  @Input() haveFilter = false;
  @Input() showFilter = false;
  @Input() showBtnFilter = false;
  @Input() canSync = false;
  @Input() canAdd = false;
  @Input() canBack = false;
  @Input() canExportCSV = false;
  @Input() headerTitle: string;
  @Output() create = new EventEmitter();
  @Output() openFilter = new EventEmitter();
  @Output() exportCSV = new EventEmitter();
  @Output() synchronize = new EventEmitter();

  constructor(private location: Location, private router: Router) {}

  ngOnInit() {}

  onBack() {
    window.history.length > 1 ? this.location.back() : this.router.navigate(['/']);
  }

  onCreate() {
    this.create.next();
  }

  toggleFilter() {
    this.showFilter = !this.showFilter;
    if (this.showFilter === true) {
      this.openFilter.emit();
    }
  }
}




