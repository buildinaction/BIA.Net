export interface Role {
  id: number;
  label: string;
}
