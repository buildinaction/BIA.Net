export interface UserFilter {
  filter: string;
  ldapName: string;
}
