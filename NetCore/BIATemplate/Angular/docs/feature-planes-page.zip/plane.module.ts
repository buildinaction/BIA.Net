import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { PlanesEffects } from './store/planes-effects';
import { reducers } from './store/plane.state';
import { PlaneFormComponent } from './components/plane-form/plane-form.component';
import { PlanesIndexComponent } from './views/planes-index/planes-index.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { PlaneNewComponent } from './views/plane-new/plane-new.component';
import { PlaneEditComponent } from './views/plane-edit/plane-edit.component';
import { Permission } from 'src/app/shared/permission';
import { PermissionGuard } from 'src/app/core/bia-core/guards/permission.guard';

const ROUTES: Routes = [
  {
    path: '',
    data: {
      breadcrumb: null,
      permission: Permission.Plane_List_Access
    },
    component: PlanesIndexComponent,
    canActivate: [PermissionGuard]
  },
  {
    path: 'create',
    data: {
      breadcrumb: 'bia.add',
      canNavigate: false,
      permission: Permission.Plane_Create
    },
    component: PlaneNewComponent,
    canActivate: [PermissionGuard]
  },
  {
    path: 'edit/:id',
    data: {
      breadcrumb: 'bia.edit',
      canNavigate: false,
      permission: Permission.Plane_Update
    },
    component: PlaneEditComponent,
    canActivate: [PermissionGuard]
  },
  { path: '**', redirectTo: '' }
];

@NgModule({
  declarations: [PlaneFormComponent, PlanesIndexComponent, PlaneNewComponent, PlaneEditComponent],
  imports: [
    SharedModule,
    RouterModule.forChild(ROUTES),
    StoreModule.forFeature('planes-mode-page', reducers),
    EffectsModule.forFeature([PlanesEffects])
  ]
})
export class PlaneModule {}
