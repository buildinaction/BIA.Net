module app.module.Exemple {
    $(document).ready(function () {
        setTimeout(function () { BIA.Net.Dialog.ChangeContent("#DivSiteList", "/$saferootprojectname$/Site/") },3000);
    });
}