CREATE UNIQUE NONCLUSTERED INDEX [UX_Login] ON [dbo].[User]
(
	[Login] ASC
)
GO