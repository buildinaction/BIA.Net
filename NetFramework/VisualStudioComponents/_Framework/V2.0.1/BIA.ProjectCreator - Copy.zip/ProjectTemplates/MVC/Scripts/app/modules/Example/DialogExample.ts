﻿module app.module.Exemple {
    declare var UrlSiteIndex: string;
    $(document).ready(function () {
        setTimeout(function () { BIA.Net.Dialog.ChangeContent("#DivSiteList", UrlSiteIndex) },3000);
    });
}