﻿namespace $safeprojectname$.Helpers
{
    using System.Web.Http.Controllers;
    using System.Web.Http.ExceptionHandling;
    using BIA.Net.Common;

    public class TraceExceptionLogger : ExceptionLogger
    {
        /// <inheritdoc/>
        public override void Log(ExceptionLoggerContext context)
        {
            HttpActionContext actionContext = ((System.Web.Http.ApiController)context.ExceptionContext.ControllerContext.Controller).ActionContext;
            TraceManager.Error(HttpActionContextHelper.GetControllerName(actionContext), HttpActionContextHelper.GetActionName(actionContext), context.ExceptionContext.Exception.Message, context.ExceptionContext.Exception);

            base.Log(context);
        }
    }
}