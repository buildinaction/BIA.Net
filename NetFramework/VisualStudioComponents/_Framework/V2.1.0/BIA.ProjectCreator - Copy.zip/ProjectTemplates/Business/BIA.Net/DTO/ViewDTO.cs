namespace BIA.Net.Business.DTO
{
    using BIA.Net.Business.DTO.Infrastructure;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Linq.Expressions;
    using $companyName$.$saferootprojectname$.Model;

    /// <summary>
    /// Type of the view in the grid
    /// </summary>
    public enum TypeOfView
    {
        /// <summary>
        /// Default System
        /// </summary>
        Undefined = -1,

        /// <summary>
        /// Default System
        /// </summary>
        SystemDefault = 0,

        /// <summary>
        /// Site
        /// </summary>
        Site = 1,

        /// <summary>
        /// User
        /// </summary>
        User = 2,
    }

#pragma warning disable CS1591 // Missing XML Comment
#pragma warning disable SA1600 // Elements must be documented
#pragma warning disable SA1402 // File may only contain one single class
    public class ViewDTO
    {
        ////BCC/ BEGIN CUSTOM CODE SECTION
        public ViewDTO()
        {
            SitesAssigned = new List<int>();
            SitesIsDefault = new List<int>();
        }

        /// <summary>
        /// Gets or sets a value indicating whether define if the view grouped for the site is default or if the view for the user is default
        /// </summary>
        public bool IsDefaultView { get; set; }

        public string Comment { get; set; }

        public IEnumerable<int> SitesAssigned { get; set; }

        public IEnumerable<int> SitesIsDefault { get; set; }

        ////ECC/ END CUSTOM CODE SECTION

        [Required]
        public int Id { get; set; }

        [StringLength(100)]
        [Required]
        public string TableId { get; set; }

        [StringLength(50)]
        [Required]
        public string Name { get; set; }

        [StringLength(500)]
        public string Description { get; set; }

        [Required]
        public string Preference { get; set; }

        [Required]
        public TypeOfView ViewType { get; set; }
    }

    public class Preference<FilterAdvanced>
    {
        public FilterAdvanced advancedFilterValues { get; set; }

        /*public Dictionary<int, string> headerFilterValues { get; set; }

        public object datatableOption { get; set; }*/
    }

    public class ViewMapper : MapperBase<View, ViewDTO>
    {
        ////BCC/ BEGIN CUSTOM CODE SECTION
        ////ECC/ END CUSTOM CODE SECTION
        public override Expression<Func<View, ViewDTO>> SelectorExpression
        {
            get
            {
                return p => new ViewDTO()
                {
                    ////BCC/ BEGIN CUSTOM CODE SECTION
                    ////ECC/ END CUSTOM CODE SECTION
                    Id = p.Id,
                    TableId = p.TableId,
                    Name = p.Name,
                    Description = p.Description,
                    Preference = p.Preference,
                    ViewType = (TypeOfView)p.ViewType,
                    IsDefaultView = false
                };
            }
        }

        public override void MapToModel(ViewDTO dto, View model)
        {
            ////BCC/ BEGIN CUSTOM CODE SECTION
            ////ECC/ END CUSTOM CODE SECTION
            model.Id = dto.Id;
            model.TableId = dto.TableId;
            model.Name = dto.Name;
            model.Description = dto.Description;
            model.Preference = dto.Preference;
            model.ViewType = (int)dto.ViewType;
        }
    }
#pragma warning restore CS1591 // Missing XML Comment
#pragma warning restore SA1600 // Elements must be documented
#pragma warning restore SA1402 // File may only contain one single class
}