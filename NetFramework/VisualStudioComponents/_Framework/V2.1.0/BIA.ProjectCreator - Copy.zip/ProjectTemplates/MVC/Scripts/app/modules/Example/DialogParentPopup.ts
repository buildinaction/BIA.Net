﻿module app.module.Exemple {
    /*
    $(document).ready(function () {
        $(window).on('OnBIADialogAction', function (e) {
            if (e.action == "SubmitAndSubmitParent") {
                if ((e.dialogDiv != null) && (e.dialogDiv.parent != null)) {
                    e.dialogDiv.parent.dialogElem.find('#DialogParentPopup').each(function () {
                        e.preventDefault();    //stop form from submitting
                        BIA.Net.Dialog.AjaxLoading.ManageSubmitFormInDialog(e.dialogDiv.parent, $(this));
                    });
                }
            }
            else if (e.action == "SubmitAndCloseParent") {
                if ((e.dialogDiv != null) && (e.dialogDiv.parent != null)) {
                    e.dialogDiv.parent.dialogElem.find('#DialogParentPopup').each(function () {
                        e.dialogDiv.parent.dialogElem.dialog("close");
                    });
                }
            }
            else {
                if ((e.dialogDiv != null) && (e.dialogDiv.parent != null)) {
                    e.dialogDiv.parent.dialogElem.find('#DialogParentPopup').each(function () {
                        e.dialogDiv.dialogElem.dialog('close');
                        alert("action not implemented :" + e.action);
                    });
                }
            }
        });
    });*/
}