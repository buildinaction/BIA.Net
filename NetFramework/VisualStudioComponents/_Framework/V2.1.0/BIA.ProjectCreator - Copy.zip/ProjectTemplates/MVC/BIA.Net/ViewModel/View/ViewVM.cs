﻿namespace BIA.Net.MVC.ViewModel.View
{
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    /// <summary>
    /// Class to manage a view
    /// </summary>
    public class ViewVM
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ViewVM"/> class.
        /// </summary>
        public ViewVM()
        {
            Id = 0;
            SiteAssignedId = new List<int>();
            SiteViewDefaultId = new List<int>();
        }

        /// <summary>
        ///  Gets or sets the id of the view
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        ///  Gets or sets name of the view
        /// </summary>
        [StringLength(50)]
        public string Name { get; set; }

        /// <summary>
        ///  Gets or sets the description of the view
        /// </summary>
        [StringLength(500)]
        public string Description { get; set; }

        /// <summary>
        ///  Gets or sets the differents paramaters for the grid (advanced filter, grid, header)
        /// </summary>
        public string Parameters { get; set; }

        /// <summary>
        ///  Gets or sets specific comment
        /// </summary>
        public string Comment { get; set; }

        /// <summary>
        ///  Gets or sets a value indicating whether define if the view is system or site
        /// </summary>
        public bool IsReference { get; set; }

        /// <summary>
        ///  Gets or sets a value indicating whether define if the view is the default view
        /// </summary>
        public bool IsDefaultView { get; set; }

        /// <summary>
        ///  Gets or sets a value indicating whether define if the view is the current view
        /// </summary>
        public bool IsCurrentView { get; set; }

        /// <summary>
        ///  Gets or sets the list of the view is potentially assigned
        /// </summary>
        public IEnumerable<int> SiteAssignedId { get; set; }

        /// <summary>
        ///  Gets or sets the list of the view is potentially like a default view
        /// </summary>
        public IEnumerable<int> SiteViewDefaultId { get; set; }

        /// <summary>
        ///  Gets the name fo the view
        /// </summary>
        /// <returns>return the name of the view</returns>
        public override string ToString()
        {
            return Name;
        }
    }
}