namespace BIA.Net.MVC.Controllers.View
{
    using BIA.Net.Business.DTO;
    using BIA.Net.Business.Services;
    using BIA.Net.Common.Helpers;
    using BIA.Net.MVC.ViewModel.View;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web.Mvc;
    using $companyName$.$saferootprojectname$.Business.DTO;
    using $companyName$.$saferootprojectname$.Business.Helpers;
    using $companyName$.$saferootprojectname$.Business.Services;
    using $companyName$.$saferootprojectname$.Common;
    using $companyName$.$saferootprojectname$.Common.Resources.BIA.Net;
    using $safeprojectname$.Controllers;
    using static BIA.Net.Business.Services.AllServicesDTO;

    /// <summary>
    /// Controller for view page
    /// </summary>
    /// <seealso cref="BaseController" />
    public class ViewController : BaseController
    {
        /// <summary>
        /// The service view
        /// </summary>
        private ServiceView serviceView;

        /// <summary>
        /// The service site
        /// </summary>
        private ServiceSite serviceSite;

        /// <summary>
        /// list of the sites for the current user
        /// </summary>
        private IEnumerable<int> sitesUser = new List<int>();

        /// <summary>
        /// Id of the current User
        /// </summary>
        private int userId = 0;

        /// <summary>
        /// Id of the current User
        /// </summary>
        private bool isSiteAdmin = false;

        /// <summary>
        /// Initializes a new instance of the <see cref="ViewController"/> class.
        /// </summary>
        public ViewController()
        {
            // Retrieve user Id and the site associated
            UserInfo userInfo = (UserInfo)UserInfo.GetCurrentUserInfo();
            sitesUser = userInfo.Properties.Members?.Select(x => x.SiteId).ToList() ?? new List<int>();
            userId = userInfo.Properties.Id;
            isSiteAdmin = userInfo.IsInRole(Constants.RoleSiteAdmin) || userInfo.IsInRole(Constants.RoleAdmin);

            // Init the services
            serviceView = BIAUnity.Resolve<ServiceView>();
            serviceSite = BIAUnity.Resolve<ServiceSite>();
        }

        /// <summary>
        /// Function to display the popup of the view
        /// </summary>
        /// <param name="tableId">If of the table</param>
        /// <param name="currentViewId">Id of the current view</param>
        /// <returns>Return the partial of the popup view generated</returns>
        public ActionResult ShowPopup(string tableId, int currentViewId = 0)
        {
            ViewPopupVM temp = GetVMPopup(tableId, currentViewId, 0);

            // Generate the view from the partial and the ViewModel
            return PartialView("~/Views/Shared/BIA.Net/Views/ViewsPopup.cshtml", temp);
        }

        /// <summary>
        /// Return the list of site views
        /// </summary>
        /// <param name="tableId">the table id</param>
        /// <param name="siteId">the site Id</param>
        /// <returns>the list of site views</returns>
        public ActionResult _ListSiteViews(string tableId, int siteId = 0)
        {
            // Generate the view from the partial and the ViewModel
            ViewPopupVM temp = GetVMPopup(tableId, 0, siteId);
            return PartialView("~/Views/Shared/BIA.Net/Views/_ListSiteViews.cshtml", temp);
        }

        /// <summary>
        /// Function to Delete an site/user view
        /// </summary>
        /// <param name="tableId">Id of the table</param>
        /// <param name="viewId">Id of the view</param>
        /// <param name="isSite">Define if the deletion for a view from site</param>
        /// <param name="siteId">Id of the site</param>
        /// <returns>Return the partial of the viewpopup updated</returns>
        public ActionResult DeleteView(string tableId, int viewId, bool isSite, int siteId = 0)
        {
            string notif = TextResources.ErrorOccurredWhileProccessing;

            if (isSite)
            {
                // Call the service to delete the site view
                serviceView.DeleteSiteView(viewId);
            }
            else
            {
                // Call the service to delete the user view
                serviceView.DeleteUserView(viewId);
            }

            notif = TextResources.UpdatedSuccessfully;

            // Return the partial of the viewpopup updated
            return GetListsMultiContents(tableId, siteId);
        }

        /// <summary>
        /// Function to set a view to a user/site like default view at the first loading for a new sesssion
        /// </summary>
        /// <param name="tableId">Id of the table</param>
        /// <param name="viewId">Id of view</param>
        /// <param name="active">Define if the default value is to set or to remove</param>
        /// <param name="isSite">Define if the view to set by default is for a site or not</param>
        /// <param name="siteId">Id of the site</param>
        /// <returns>Return the partial of the viewpopup updated</returns>
        public ActionResult SetDefaultView(string tableId, int viewId, bool active, bool isSite, int siteId = 0)
        {
            string notif = TextResources.ErrorOccurredWhileProccessing;

            if (isSite)
            {
                // Call the service to set the site view like default view
                serviceView.SetSiteDefaultView(viewId, active, siteId);
            }
            else
            {
                // Call the service to set the user view like default view
                serviceView.SetUserDefaultView(viewId, active);
            }

            notif = TextResources.UpdatedSuccessfully;

            return GetListsMultiContents(tableId, siteId);
        }

        /// <summary>
        /// Function to set a view to a user like default view at the first loading for a new sesssion
        /// </summary>
        /// <param name="tableId">Id of the table</param>
        /// <param name="viewId">Id of view</param>
        /// <param name="add">Define if the action is to add or delete</param>
        /// <param name="siteId">Id of the site</param>
        /// <returns>Return the partial of the viewpopup updated</returns>
        public ActionResult AssignViewToSite(string tableId, int viewId, bool add, int siteId)
        {
            string notif = TextResources.ErrorOccurredWhileProccessing;

            // Call the service to add or delete the view from a site
            if (add)
            {
                serviceView.AssignViewToSite(viewId, siteId);
            }
            else
            {
                serviceView.UnassignViewToSite(viewId, siteId);
            }

            notif = TextResources.UpdatedSuccessfully;

            // Return the partial of the viewpopup updated
            return GetListsMultiContents(tableId, siteId);
        }

        #region Update and Create the view

        /// <summary>
        /// Function to update a view
        /// </summary>
        /// <param name="tableId">Id of the table</param>
        /// <param name="viewId">Id of the view</param>
        /// <param name="preference">Table options to update</param>
        /// <param name="isSiteView">Define if the action is for the site or not</param>
        /// <param name="siteId">Id of the site</param>
        /// <returns>Return the partial of the viewpopup updated</returns>
        public ActionResult UpdateView(string tableId, int viewId, string preference,  bool isSiteView, int siteId = 0)
        {
            string notif = TextResources.ErrorOccurredWhileProccessing;

            ViewDTO currentView = serviceView.GetView(viewId);

            // Changing preference of the table
            currentView.Preference = preference;

            // Update the view
            serviceView.UpdateValues(currentView, new List<string>() { nameof(ViewDTO.Preference) });

            notif = TextResources.UpdatedSuccessfully;

            // Return the partial of the viewpopup updated
            return GetListsMultiContents(tableId, siteId);
        }

        /// <summary>
        /// Function to create a view
        /// </summary>
        /// <param name="tableId">Id of the table</param>
        /// <param name="name">Name of the view</param>
        /// <param name="description">Description of the view</param>
        /// <param name="preference">Options of the table</param>
        /// <param name="isSiteView">Define of the view is a site view</param>
        /// <param name="siteId">Id of the site to associate to the view</param>
        /// <returns>Return the partial of the viewpopup updated</returns>
        public ActionResult CreateView(string tableId, string name, string description, string preference, bool isSiteView, int siteId = 0)
        {
            string notif = TextResources.ErrorOccurredWhileProccessing;

            // Check if the name is define
            if (string.IsNullOrEmpty(name))
            {
                notif = TextResources.View_NameUndefined;
            }
            else
            {
                // check if the view is for a site and sites are defined
                if (isSiteView && (siteId == 0))
                {
                    notif = TextResources.View_SiteUndefined;
                }
                else if (isSiteView)
                {
                    // Parse each site to create a relation with the view and the site
                    SiteViewDTO newView = new SiteViewDTO()
                    {
                        SiteId = siteId,
                        View = new ViewDTO()
                        {
                            Name = name,
                            Description = description,
                            Preference = preference,
                            TableId = tableId,
                            ViewType = TypeOfView.Site
                        }
                    };

                    // Create the view for this site
                    serviceView.CreateView(newView);
                }
                else
                {
                    UserViewDTO newView = new UserViewDTO()
                    {
                        UserId = userId,
                        View = new ViewDTO()
                        {
                            Name = name,
                            Description = description,
                            Preference = preference,
                            TableId = tableId,
                            ViewType = TypeOfView.User
                        }
                    };

                    // Create the view for an user
                    serviceView.CreateView(newView);
                }

                notif = TextResources.CreatedSuccessfully;
            }

            // Return the partial of the viewpopup updated
            return GetListsMultiContents(tableId, siteId);
        }

        #endregion

        /// <summary>
        /// retrun the view model used to display ViewsPopup
        /// </summary>
        /// <param name="tableId">the table id</param>
        /// <param name="currentViewId">the current view id</param>
        /// <param name="siteId">the site Id</param>
        /// <returns>the view model used to display ViewsPopup</returns>
        private ViewPopupVM GetVMPopup(string tableId, int currentViewId, int siteId)
        {
            // Retrieve all sites to manage site views
            List<SiteDTO> listSite = new List<SiteDTO>();

            if (isSiteAdmin)
            {
                listSite = serviceSite.GetAllWhere(x => sitesUser.Contains(x.Id), ServiceAccessMode.Read).Distinct().OrderBy(s => s.Title).ToList();
            }

            // Define the site selected to manage the views
            SiteDTO site = listSite.FirstOrDefault(x => x.Id == siteId);

            // List all the view for this user and table
            List<ViewDTO> views = serviceView.GetViews(tableId);

            List<ViewVM> allViews = new List<ViewVM>(views.Count);
            allViews.AddRange(views.Where(x => x.ViewType == TypeOfView.SystemDefault).OrderBy(f => f.Name).Select(f => new ViewVM()
            {
                Id = f.Id,
                Name = f.Name,
                Description = f.Description,
                IsReference = true,
                Comment = string.Empty,
                IsDefaultView = f.IsDefaultView,
                IsCurrentView = currentViewId == f.Id,
                SiteAssignedId = new List<int>(),
                SiteViewDefaultId = new List<int>()
            }));
            allViews.AddRange(views.Where(x => x.ViewType == TypeOfView.Site).OrderBy(f => f.Name).Select(f => new ViewVM()
            {
                Id = f.Id,
                Name = f.Name,
                Description = f.Description,
                IsReference = true,
                Comment = f.Comment,
                IsDefaultView = f.IsDefaultView,
                IsCurrentView = currentViewId == f.Id,
                SiteAssignedId = f.SitesAssigned,
                SiteViewDefaultId = f.SitesIsDefault
            }));
            allViews.AddRange(views.Where(x => x.ViewType == TypeOfView.User).OrderBy(f => f.Name).Select(f => new ViewVM()
            {
                Id = f.Id,
                Name = f.Name,
                Description = f.Description,
                IsReference = false,
                Comment = string.Empty,
                IsDefaultView = f.IsDefaultView,
                IsCurrentView = currentViewId == f.Id,
                SiteAssignedId = new List<int>(),
                SiteViewDefaultId = new List<int>()
            }));

            if (siteId == 0)
            {
                List<int> siteWithViews = views.Where(x => x.ViewType == TypeOfView.Site).SelectMany(x => x.SitesAssigned).Distinct().Where(x => sitesUser.Contains(x)).ToList();
                if (siteWithViews.Any())
                {
                    site = listSite.FirstOrDefault(x => siteWithViews.Contains(x.Id));
                }
            }

            // Define the list view for the site
            List<ViewVM> currentViewSiteSelected = new List<ViewVM>();
            if (views.Where(x => x.ViewType == TypeOfView.Site).Any())
            {
                currentViewSiteSelected = views.Where(x => x.ViewType == TypeOfView.Site).OrderBy(f => f.Name).Select(f => new ViewVM()
                {
                    Id = f.Id,
                    Name = f.Name,
                    Description = f.Description,
                    IsReference = true,
                    Comment = f.Comment,
                    IsDefaultView = f.IsDefaultView,
                    SiteAssignedId = f.SitesAssigned,
                    SiteViewDefaultId = f.SitesIsDefault
                }).ToList();
            }

            // Define the default view
            int defaultViewId = views.FirstOrDefault(f => f.IsDefaultView).Id;
            ViewVM defaultView = allViews.FirstOrDefault(f => f.Id == defaultViewId);

            // Define the current view for the user
            ViewVM currentView = allViews.FirstOrDefault(x => x.Id == currentViewId);
            if (currentView == null)
            {
                currentView = allViews.FirstOrDefault(x => x.Id == 0);
            }

            // Define the current view for the site
            ViewVM currentViewSite = allViews.Where(x => x.IsReference && x.Id > 0).FirstOrDefault(x => x.Id == currentViewId);
            if (currentViewSite == null)
            {
                currentViewSite = allViews.Where(x => x.IsReference && x.Id > 0).FirstOrDefault();
            }

            SelectList sitesPossible = new SelectList(listSite.OrderBy(f => f.Title), "Id", "Title");

            bool isAdmin = (User.IsInRole(Constants.RoleAdmin) || User.IsInRole(Constants.RoleSiteAdmin)) && ((IEnumerable<SelectListItem>)sitesPossible).Count() > 0;

            // Create the popup view model
            ViewPopupVM vm = new ViewPopupVM()
            {
                UserDefaultView = defaultView,
                Views = allViews.ToArray(),
                SelectedSite = site,
                SiteViews = currentViewSiteSelected.ToArray(),
                CurrentView = currentView,
                ViewToReplace = currentView,
                SiteViewToReplace = currentViewSite,
                TableId = tableId,

                // Views of the user to override existing
                UserViews = new SelectList(allViews.Where(f => !f.IsReference), nameof(ViewVM.Id), nameof(ViewVM.Name)),

                // Views associed to the site yet
                SitesDefaultViews = new SelectList(allViews.Where(f => f.IsReference && f.Id > 0).Where(x => site != null && x.SiteAssignedId.Contains(site.Id)).OrderByDescending(f => f.IsReference).ThenBy(f => f.Name), nameof(ViewVM.Id), nameof(ViewVM.Name)),

                // List of the site to manage
                SitesPossible = sitesPossible,

                IsAdmin = isAdmin,
            };

            return vm;
        }

        /// <summary>
        /// Retrun the html for the 3 lists
        /// </summary>
        /// <param name="tableId">the table Id</param>
        /// <param name="siteId">the site If</param>
        /// <returns>the html for the 3 lists</returns>
        private ActionResult GetListsMultiContents(string tableId, int siteId)
        {
            ViewPopupVM temp = GetVMPopup(tableId, 0, siteId);
            return Json(
                new
                {
                    ListSiteViews = temp.IsAdmin ? RenderPartialToString("~/Views/Shared/BIA.Net/Views/_ListSiteViews.cshtml", temp) : string.Empty,
                    ListMyViews = RenderPartialToString("~/Views/Shared/BIA.Net/Views/_ListMyViews.cshtml", temp),
                    ListManageMyViews = RenderPartialToString("~/Views/Shared/BIA.Net/Views/_ListManageMyViews.cshtml", temp),
                },
                JsonRequestBehavior.AllowGet);
        }
    }
}