namespace BIA.Net.MVC.ViewModel.View
{
    using System.Web.Mvc;
    using $companyName$.$saferootprojectname$.Business.DTO;

    /// <summary>
    /// Class to mange the ViewModel of the Popup of the view
    /// </summary>
    public class ViewPopupVM
    {
        /// <summary>
        /// Gets or sets the table id
        /// </summary>
        public string TableId { get; set; }

        /// <summary>
        /// Gets or sets List of the views associated to the table
        /// </summary>
        public ViewVM[] Views { get; set; }

        /// <summary>
        /// Gets or sets the current view for the user
        /// </summary>
        public ViewVM CurrentView { get; set; }

        /// <summary>
        /// Gets or sets the a view for the user to replace
        /// </summary>
        public ViewVM ViewToReplace { get; set; }

        /// <summary>
        /// Gets or sets the a view for the user to replace
        /// </summary>
        public ViewVM SiteViewToReplace { get; set; }

        /// <summary>
        /// Gets or sets the user default view by default
        /// </summary>
        public ViewVM UserDefaultView { get; set; }

        /// <summary>
        /// Gets or sets the list id of sites to manage
        /// </summary>
        public SiteDTO SelectedSite { get; set; }

        /// <summary>
        /// Gets or sets List of the views associated to the table for a site
        /// </summary>
        public ViewVM[] SiteViews { get; set; }

        /// <summary>
        /// Gets or sets Name of the new view
        /// </summary>
        public string NewNameView { get; set; }

        /// <summary>
        /// Gets or sets Description of the new view
        /// </summary>
        public string DescriptionView { get; set; }

        /// <summary>
        /// Gets or sets Name of the new view
        /// </summary>
        public string NewNameViewSite { get; set; }

        /// <summary>
        /// Gets or sets Description of the new view
        /// </summary>
        public string DescriptionViewSite { get; set; }

        /// <summary>
        /// Gets or sets views of the user to override existing
        /// </summary>
        public SelectList UserViews { get; set; }

        /// <summary>
        ///  Gets or sets views associed to the site yet
        /// </summary>
        public SelectList SitesDefaultViews { get; set; }

        /// <summary>
        /// Gets or sets list of the site to manage
        /// </summary>
        public SelectList SitesPossible { get; set; }

        /// <summary>
        ///  Gets or sets a value indicating whether the user is SiteAdmin
        /// </summary>
        public bool IsAdmin { get; set; }
    }
}