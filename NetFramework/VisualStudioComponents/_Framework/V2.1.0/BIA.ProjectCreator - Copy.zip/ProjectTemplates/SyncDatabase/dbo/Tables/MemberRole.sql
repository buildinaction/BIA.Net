﻿CREATE TABLE [dbo].[MemberRole] (
    [Id]    INT            NOT NULL,
    [Title] NVARCHAR (100) NOT NULL,
    CONSTRAINT [PK_MemberRole] PRIMARY KEY CLUSTERED ([Id] ASC)
);

