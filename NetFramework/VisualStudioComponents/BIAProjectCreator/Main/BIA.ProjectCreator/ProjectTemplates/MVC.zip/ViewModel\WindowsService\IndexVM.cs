﻿namespace $safeprojectname$.ViewModel.WindowsService
{
    /// <summary>
    /// WindowsService VM
    /// </summary>
    public class IndexVM
    {
        /// <summary>
        /// Gets or sets status of WindowsService
        /// </summary>
        public string Status { get; set; }
    }
}